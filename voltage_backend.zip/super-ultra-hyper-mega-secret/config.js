module.exports = {
    uri: 'postgres://postgres:BuSinka336@localhost:5432/voltage'
}