module.exports = {
    salt: '$2b$12$GZxvwD/g4UnQB5uGCaAJ7e'
};